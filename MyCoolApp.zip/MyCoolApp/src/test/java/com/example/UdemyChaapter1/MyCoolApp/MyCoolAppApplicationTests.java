package com.example.UdemyChaapter1.MyCoolApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyCoolAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
